echo 'Please, inform BIG-IP managemnt IP, username and password to connect to the BIG-IP'
read -p 'BIG-IP mgmt IP: ' host
read -p 'Username: ' user
read -sp 'Password: ' pass
echo ''

# Collect text from all rules and put in variable rule_text.
rules=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/rule | jq .items[].apiAnonymous | awk 1 ORS=' ')
rule_text=($(echo "$rules" | tr ' ' '\n'))
# echo "-iRule text----------------------------------"
# echo "${rule_text[@]}"
# echo "---------------------------------------------"

# Collect text from all rules in all traffic policies and put in variable policy_text.
traffic_policy=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/policy | jq -r .items[].fullPath | awk 1 ORS=' ')
traffic_policy_text=()
for policy in $traffic_policy
do
   policy=$(echo "$policy" | awk '{gsub("/", "~", $0); print}')
   traffic_policy_text+=($(curl -sku $user:$pass https://$host/mgmt/tm/ltm/policy/$policy/rules?expandSubcollections=true | jq .items[].conditionsReference?.items[]?.datagroup? | awk 1 ORS=' '))
done
# echo "-Traffic Policy Datagroups-------------------"
# echo "${traffic_policy_text[@]}"
# echo "---------------------------------------------"

# Collect names from all internal datagroup records and put in variable datagroup_names_list.
datagroup_names=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/data-group/internal | jq -r .items[].name | awk 1 ORS=' ')
datagroup_name_list=($(echo "$datagroup_names" | tr ' ' '\n'))
# echo "-Datagroup Names-----------------------------"
# echo "${datagroup_name_list[@]}"
# echo "---------------------------------------------"

# Collect fullPaths from all internal datagroup records and put in variable datagroup_fullPaths_list.
datagroup_fullPaths=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/data-group/internal | jq -r .items[].fullPath | awk 1 ORS=' ')
datagroup_fullPath_list=($(echo "$datagroup_fullPaths" | tr ' ' '\n'))
# echo "-Datagroup fullPaths-------------------------"
# echo "${datagroup_fullPath_list[@]}"
# echo "---------------------------------------------"

# System datagroup list for exclusion on orphan checks.
system_datagroup_fullPaths=("/Common/aol" "/Common/images" "/Common/private_net")

echo "Checking for orphan internal datagroups -"
echo ""

# Iterate through entries in datagroup_name_list
len=${#datagroup_name_list[@]}
for (( i=0; i<$len; i++))
do
  # Initialize orphan flag to true
  orphan=true
  # For each entry in datagroup_name_list, check to see if it is in rule_text or datagroup_test arrays.
  # If found set orphan flag to false.

  [[ "${system_datagroup_fullPaths[@]}" =~ "${datagroup_fullPath_list[$i]}" ]] && continue || echo null >/dev/null

  [[ "${rule_text[@]}" =~ ([[:space:]])"${datagroup_name_list[$i]}"([[:space:]]|]) ]] && orphan=false || echo null >/dev/null
  [[ "${rule_text[@]}" =~ ([[:space:]])"${datagroup_fullPath_list[$i]}"([[:space:]]|]) ]] && orphan=false || echo null >/dev/null

  [[ "${traffic_policy_text[@]}" =~ "\"${datagroup_fullPath_list[$i]}\"" ]] && orphan=false || echo null >/dev/null

  # If orphan flag is still true, than report status
  if $orphan
  then
     echo "   ${datagroup_fullPath_list[$i]}  --  Orphaned"
  fi
done
