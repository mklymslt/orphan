echo 'Please, inform BIG-IP managemnt IP, username and password to connect to the BIG-IP'
read -p 'BIG-IP mgmt IP: ' host
read -p 'Username: ' user
read -sp 'Password: ' pass
echo ''

# Collect virtual server default pool references.  Put all pool names in variable vs_pools.
vs_pools=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/virtual | jq .items[].pool? | awk 1 ORS=' ')
vs_pool_list=($(echo "$vs_pools" | tr ' ' '\n'))
# echo "-Virtual Server Pools------------------------"
# echo "${vs_pool_list[@]}"
# echo "---------------------------------------------"

# Collect text from all rules and put in variable rule_text.
rules=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/rule | jq .items[].apiAnonymous | awk 1 ORS=' ')
rule_text=($(echo "$rules" | tr ' ' '\n'))
# echo "-iRule text----------------------------------"
# echo "${rule_text[@]}"
# echo "---------------------------------------------"

# Collect text from all rules in all traffic policies and put in variable policy_text.
traffic_policy=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/policy | jq -r .items[].fullPath | awk 1 ORS=' ')
traffic_policy_text=()
for policy in $traffic_policy
do
   policy=$(echo "$policy" | awk '{gsub("/", "~", $0); print}')
   traffic_policy_text+=($(curl -sku $user:$pass https://$host/mgmt/tm/ltm/policy/$policy/rules?expandSubcollections=true | jq .items[].actionsReference?.items[].pool? | awk 1 ORS=' '))
done
# echo "-Traffic Policy Pools------------------------"
# echo "${traffic_policy_text[@]}"
# echo "---------------------------------------------"

# Collect text from all internal datagroup records and put in variable datagroup_text.
datagroup_records=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/data-group/internal | jq .items[].records | awk 1 ORS=' ')
datagroup_text=($(echo "$datagroup_records" | tr ' ' '\n'))
# echo "-Datagroup text------------------------------"
# echo "${datagroup_text[@]}"
# echo "---------------------------------------------"

# Search Pool definitions for all pool names.  Put list of pool fullpath names in variable pool_fullpath.
pool_fullPaths=($(curl -sku $user:$pass https://$host/mgmt/tm/ltm/pool | jq -r .items[].fullPath | awk 1 ORS=' '))
pool_fullPath_list=($(echo "${pool_fullPaths[@]}" | tr ' ' '\n'))
# echo "-Pool Full Paths-----------------------------"
# echo "${pool_fullPath_list[@]}"
# echo "---------------------------------------------"

# Some objects that reference pools may use the pool name rather than the fullpath, so collect the names again and put list in variable pool_name.
pool_names=($(curl -sku $user:$pass https://$host/mgmt/tm/ltm/pool | jq -r .items[].name | awk 1 ORS=' '))
pool_name_list=($(echo "${pool_names[@]}" | tr ' ' '\n'))
# echo "-Pool Names----------------------------------"
# echo "${pool_name_list[@]}"
# echo "---------------------------------------------"

# Iterate through entries in pool_fullpath list
len=${#pool_fullPath_list[@]}
# echo "Length - $len"
for (( i=0; i<$len; i++))
do
   # Initialize orphan flag to true
   orphan=true
   # For each entry in the pool_fullpath list, check to see if it is in the any of the lists - vs_pool, rule_text, traffic_policy_text or datagroup_text.
   # Also check for corresponding entry in pool_name list.
   # If found set orphan flag to false.
   [[ "${vs_pools[@]}" =~ "\"${pool_fullPath_list[$i]}\"" ]] && orphan=false || echo null >/dev/null
   [[ "${rule_text[@]}" =~ (pool )"${pool_name_list[$i]}"(]|\\n) ]] && orphan=false || echo null >/dev/null
   [[ "${rule_text[@]}" =~ (pool )"${pool_fullPath_list[$i]}"(]|\\n) ]] && orphan=false || echo null >/dev/null
   [[ "${traffic_policy_text[@]}" =~ "\"${pool_fullPath_list[$i]}\"" ]] && orphan=false || echo null >/dev/null
   [[ "${datagroup_text[@]}" =~ "\"${pool_name_list[$i]}\"" ]] && orphan=false || echo null >/dev/null
   [[ "${datagroup_text[@]}" =~ "\"${pool_fullPath_list[$i]}\"" ]] && orphan=false || echo null >/dev/null
   # If orphan flag is still true, than report status
   if $orphan
   then
      echo "   ${pool_fullPath_list[$i]} -- Orphaned"
   fi
done
