echo 'Please, inform BIG-IP managemnt IP, username and password to connect to the BIG-IP'
read -p 'BIG-IP mgmt IP: ' host
read -p 'Username: ' user
read -sp 'Password: ' pass
echo ''

# Collect virtual server persistence profile references.  Put all persistence profile names in variable vs_persist_list.
vs_persists=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/virtual | jq .items[].persist?[]?.name | awk 1 ORS=' ')
vs_persist_list=($(echo "$vs_persists" | tr ' ' '\n'))
# echo "-Virtual Server Persistence Profiles---------"
# echo "${vs_persist_list[@]}"
# echo "---------------------------------------------"

persistence_profile_names=()

base_persistence_profile_list=("cookie" "dest_addr" "hash" "host" "msrdp" "sip" "source_addr" "ssl" "universal")
persistence_profile_types=("cookie" "dest-addr" "hash" "host" "msrdp" "sip" "source-addr" "ssl" "universal")
for typ in "${persistence_profile_types[@]}"1
do
  persistence_profiles=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/persistence/$typ | jq -r .items[]?.name? | awk 1 ORS=' ')
  persistence_profile_list=($(echo "$persistence_profiles" | tr ' ' '\n'))

  # echo "-Persistence Profile Names-"
  # echo "${persistence_profile_list[@]}"
  # echo "---------------------------"

  persistence_profile_fullPaths=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/persistence/$typ | jq -r .items[]?.fullPath? | awk 1 ORS=' ')
  persistence_profile_fullPath_list=($(echo "$persistence_profile_fullPaths" | tr ' ' '\n'))

  # echo "-Persitence Profile fullPaths-"
  # echo "${persistence_profile_fullPath_list[@]}"
  # echo "------------------------------"

  len=${#persistence_profile_list[@]}
  # echo "Length - $len"
  for (( i=0; i<$len; i++))
  do
    [[ "${base_persistence_profile_list[@]}" =~ "${persistence_profile_list[$i]}" ]] && echo null >/dev/null || persist_profile_names+=("${persistence_profile_list[$i]}");    
	[[ "${base_persistence_profile_list[@]}" =~ "${persistence_profile_list[$i]}" ]] && echo null >/dev/null || persist_profile_fullPaths+=("${persistence_profile_fullPath_list[$i]}")
  done
done

echo "Checking for orphan persistence profiles -"
echo ""

# Iterate through entries in persistence_profile_names
len=${#persist_profile_names[@]}
for (( i=0; i<$len; i++))
do
  # Initialize orphan flag to true
  orphan=true
  # For each entry in persistence_profile_names, check to see if it is in vs_persist_list array.
  # If found set orphan flag to false.
  [[ "${vs_persist_list[@]}" =~ "${persist_profile_names[$i]}" ]] && orphan=false || echo null >/dev/null
  # If orphan flag is still true, than report status
  if $orphan
  then
     echo "   ${persist_profile_fullPaths[$i]}  --  Orphaned"
  fi
done
