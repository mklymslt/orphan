echo 'Please, inform BIG-IP managemnt IP, username and password to connect to the BIG-IP'
read -p 'BIG-IP mgmt IP: ' host
read -p 'Username: ' user
read -sp 'Password: ' pass
echo ''

# Collect virtual server fullPath names - these will be used for iterative API calls.  Put all pool names in variable vs_pools.
vs_fullPaths=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/virtual | jq -r .items[].fullPath | awk 1 ORS=' ')
vs_fullPath_list=($(echo "$vs_fullPaths" | tr ' ' '\n'))
profiles_in_virtuals=()

# Find all of the profiles in virtuals and build a list of unique profile names
for vs in "${vs_fullPath_list[@]}"
do
  vs=$(echo "${vs}" | awk '{gsub("/", "~", $0); print}')
  # Collect profiles for each virtual, ignoring null results and convert to string
  vs_profiles=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/virtual/$vs/profiles | jq -r .items[].fullPath | awk 1 ORS=' ')
  # Convert string result to array to allow iteration
  vs_profile_list=($(echo "$vs_profiles" | tr ' ' '\n'))
  # Iterate through list of profiles for virtual server and add new rule names to profiles_in_virtuals array
  for vs_profile in "${vs_profile_list[@]}"
  do
    if [ "$vs_profile" != "" ]
    then
      # Add new unique profile names to rules_in_virtuals array
      [[ "${profiles_in_virtuals[@]}" =~ "$vs_profile" ]] && echo null >/dev/null || profiles_in_virtuals+=("\"$vs_profile\"")
    fi
  done
done

# echo ""
# echo "Profiles found in virtuals - ${profiles_in_virtuals[@]}"
# echo ""

# Collect text from all rules and put in variable rule_text.
rules=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/rule | jq .items[].apiAnonymous | awk 1 ORS=' ')
rule_text=($(echo "$rules" | tr ' ' '\n'))
# echo "-iRule text----------------------------------"
# echo "${rule_text[@]}"
# echo "---------------------------------------------"

# Collect names from all profiles and put in variable profile_names.

# The base profiles are based on the /config/profile_base.conf file and will be used to exclude these profiles from orphan checking.
base_profile_list=("/Common/certificateauthority" "/Common/clientssl" "/Common/clientssl-insecure-compatible" "/Common/wom-default-clientssl" "/Common/crypto-server-default-clientssl" "/Common/clientssl-secure" "/Common/splitsession-default-clientssl" "/Common/clientssl-quic" "/Common/splitsession-default-serverssl" "/Common/cloud-service-default-ssl" "/Common/f5aas-default-ssl" "/Common/dns" "/Common/dns-acceleration" "/Common/diameter" "/Common/requestadapt" "/Common/responseadapt" "/Common/icap" "/Common/connector" "/Common/service" "/Common/qoe" "/Common/traffic-acceleration" "/Common/gtp" "/Common/fix" "/Common/fasthttp" "/Common/fastL4" "/Common/security-fastL4" "/Common/netflow" "/Common/full-acceleration" "/Common/ftp" "/Common/tftp" "/Common/ipsecalg" "/Common/html" "/Common/http" "/Common/http-transparent" "/Common/http-explicit" "/Common/httprouter" "/Common/http2" "/Common/http3" "/Common/quic" "/Common/websocket" "/Common/splitsessionclient" "/Common/splitsessionserver" "/Common/http-proxy-connect" "/Common/pop3" "/Common/imap" "/Common/smtps" "/Common/clientldap" "/Common/serverldap" "/Common/mqtt" "/Common/httpcompression" "/Common/wan-optimized-compression" "/Common/oneconnect" "/Common/pptp" "/Common/radiusLB" "/Common/radiusLB-subscriber-aware" "/Common/request-log" "/Common/rewrite" "/Common/ilx" "/Common/rewrite-portal" "/Common/rewrite-uri-translation" "/Common/rtsp" "/Common/serverssl" "/Common/apm-default-serverssl" "/Common/serverssl-insecure-compatible" "/Common/wom-default-serverssl" "/Common/crypto-client-default-serverssl" "/Common/pcoip-default-serverssl" "/Common/sctp" "/Common/analytics" "/Common/tcp-analytics" "/Common/classification" "/Common/classification_pem" "/Common/classification_apm_swg" "/Common/sip" "/Common/stats" "/Common/stream" "/Common/pcp" "/Common/nat-stats" "/Common/f5-tcp-progressive" "/Common/f5-tcp-wan" "/Common/f5-tcp-lan" "/Common/f5-tcp-mobile" "/Common/tcp" "/Common/tcp-legacy" "/Common/mptcp-mobile-optimized" "/Common/tcp-mobile-optimized" "/Common/tcp-lan-optimized" "/Common/tcp-wan-optimized" "/Common/wom-tcp-lan-optimized" "/Common/wom-tcp-wan-optimized" "/Common/splitsession-default-tcp" "/Common/dhcpv4" "/Common/dhcpv4_fwd" "/Common/dhcpv6" "/Common/dhcpv6_fwd" "/Common/udp" "/Common/udp_preserve_ttl" "/Common/udp_decrement_ttl" "/Common/udp_gtm_dns" "/Common/ipother" "/Common/mapt" "/Common/socks" "/Common/optimized-acceleration" "/Common/optimized-caching" "/Common/webacceleration" "/Common/websecurity" "/Common/xml" "/Common/apm-enduser-if-cache" "/Common/apm-forwarding-client-tcp" "/Common/apm-forwarding-server-tcp" "/Common/apm-forwarding-fastL4" "/Common/access-logonpage-protection-connector" "/Common/access-logonpage-protection-service" "/Common/wam-tcp-lan-optimized" "/Common/wam-tcp-wan-optimized" "/Common/serverssl-secure")

#echo "#######################"
#echo "${base_profile_list[@]}"
#echo "#######################"

# The profile_types was pulled from documentation and the Big-IP config and will be used to iterate through the profile types and collect all profiles on the device.
profile_types=("analytics" "certificate-authority" "classification" "client-ldap" "client-ssl" "connector" "dhcpv4" "dhcpv6" "diameter" "dns" "dns-acceleration" "fasthttp" "fastl4" "fix" "ftp" "gtp" "html" "http" "http2" "http3" "http-compression" "http-proxy-connect" "httprouter" "icap" "ilx" "imap" "ipother" "ipsecalg" "map-t" "mqtt" "nat-stats" "netflow" "one-connect" "pcp" "pop3" "pptp" "qoe" "quic" "radius" "request-adapt" "request-log" "response-adapt" "rewrite" "rtsp" "sctp" "server-ldap" "server-ssl" "service" "sip" "smtps" "socks" "splitsessionclient" "splitsessionserver" "statistics" "stream" "tcp" "tcp-analytics" "tftp" "traffic-acceleration" "udp" "web-acceleration" "web-security" "websocket" "xml")

# Collect names from all profiles that are not in the base_profiles_list and put in variable profile_names.
non_base_profile_name_list=()
non_base_profile_fullPath_list=()

for typ in "${profile_types[@]}"
do
  profile_fullPaths=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/profile/$typ | jq -r .items[]?.fullPath? | awk 1 ORS=' ')
  profile_fullPath_list=($(echo "$profile_fullPaths" | tr ' ' '\n'))

  # echo "--------------------------"
  # echo "${profile_fullPath_list[@]}"
  # echo "--------------------------"

  profile_names=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/profile/$typ | jq -r .items[]?.name? | awk 1 ORS=' ')
  profile_name_list=($(echo "$profile_names" | tr ' ' '\n'))

  # echo "--------------------------"
  # echo "${profile_name_list[@]}"
  # echo "--------------------------"

  len=${#profile_fullPath_list[@]}
  # echo "Length - $len"
  for (( i=0; i<$len; i++))
  do
    #echo "####  ${profile_fullPath_list[$i]}"
    [[ "${base_profile_list[@]}" =~ "${profile_fullPath_list[$i]}" ]] && echo null >/dev/null || non_base_profile_fullPath_list+=("${profile_fullPath_list[$i]}")
    [[ "${base_profile_list[@]}" =~ "${profile_fullPath_list[$i]}" ]] && echo null >/dev/null || non_base_profile_name_list+=("${profile_name_list[$i]}")
  done
done
#echo ""
#echo "Profiles configured on Big-IP -"
#echo "${non_base_profile_fullPath_list[@]}"
#echo ""

echo "Checking for orphan profiles -"
echo ""
# Iterate through entries in profle_names
len=${#non_base_profile_fullPath_list[@]}
# echo "Length - $len"
for (( i=0; i<$len; i++))
do
  # Initialize orphan flag to true
  orphan=true
  # echo "${non_base_profile_fullPath_list[$i]}"
  # echo "${non_base_profile_name_list[$i]}"
  # For each entry in profile_names, check to see if it is in profiles_in_virtuals list or in the rules_text.
  # Include \" to enclose $profile to perform exact match
  # If found set orphan flag to false.
  [[ "${profiles_in_virtuals[@]}" =~ "\"${non_base_profile_fullPath_list[$i]}\"" ]] && orphan=false || echo null >/dev/null

  # SSL Profiles can be referenced in iRules.  Since iRules are less structured, checks will be made for both the profile_names and profile_fullPath lists.
  # SSL Profile references in iRules include the SSL::profile keyword.
  [[ "${rule_text[@]}" =~ (SSL::profile )"${non_base_profile_name_list[$i]}"([[:space:]]|\\n) ]] && orphan=false || echo null >/dev/null
  [[ "${rule_text[@]}" =~ (SSL::profile )"${non_base_profile_fullPath_list[$i]}"([[:space:]]|\\n) ]] && orphan=false || echo null >/dev/null

  # If orphan flag is still true, than report status
  if $orphan
  then
    # profile=$(echo "${non_base_profile_fullPath_list[$i]}" | sed 's/\"//g')
    echo "   ${non_base_profile_fullPath_list[$i]}  --  Orphaned"
  fi
done
