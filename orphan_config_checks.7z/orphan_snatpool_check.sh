echo 'Please, inform BIG-IP managemnt IP, username and password to connect to the BIG-IP'
read -p 'BIG-IP mgmt IP: ' host
read -p 'Username: ' user
read -sp 'Password: ' pass
echo ''

# Collect virtual server persistence profile references.  Put all persistence profile names in variable vs_persist_list.
vs_snatpools=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/virtual | jq .items[].sourceAddressTranslation?.pool? | awk 1 ORS=' ')
vs_snatpool_list=($(echo "$vs_snatpools" | tr ' ' '\n'))
# echo "-Virtual Server Snatpoolss---------"
# echo "${vs_snatpool_list[@]}"
# echo "---------------------------------------------"

# Collect text from all rules and put in variable rule_text.
rules=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/rule | jq .items[].apiAnonymous | awk 1 ORS=' ')
rule_text=($(echo "$rules" | tr ' ' '\n'))
# echo "-iRule text----------------------------------"
# echo "${rule_text[@]}"
# echo "---------------------------------------------"

# Collect text from all internal datagroup records and put in variable datagroup_text.
datagroup_records=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/data-group/internal | jq .items[].records | awk 1 ORS=' ')
datagroup_text=($(echo "$datagroup_records" | tr ' ' '\n'))
# echo "-Datagroup text------------------------------"
# echo "${datagroup_text[@]}"
# echo "---------------------------------------------"

# Collect fullPaths for all snatpools
snatpool_fullPaths=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/snatpool | jq -r .items[]?.fullPath | awk 1 ORS=' ')
snatpool_fullPath_list=($(echo "$snatpool_fullPaths" | tr ' ' '\n'))
# echo "-Snatpool fullPaths--------------------------"
# echo "${snatpool_fullPath_list[@]}"
# echo "---------------------------------------------"

# Collect name for all snatpools
snatpool_names=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/snatpool | jq -r .items[]?.fullPath | awk 1 ORS=' ')
snatpool_name_list=($(echo "$snatpool_names" | tr ' ' '\n'))
# echo "-Snatpool names------------------------------"
# echo "${snatpool_name_list[@]}"
# echo "---------------------------------------------"

echo "Checking for orphan snatpool -"
echo ""

# Iterate through entries in snatpool_name_list
len=${#snatpool_name_list[@]}
for (( i=0; i<$len; i++))
do
  # Initialize orphan flag to true
  orphan=true
  # For each entry in snatpool_name_list, check to see if it is in vs_snatpool_list, rule_text or datagroup_test arrays.
  # If found set orphan flag to false.
  [[ "${vs_snatpool_list[@]}" =~ "\"${snatpool_name_list[$i]}\"" ]] && orphan=false || echo null >/dev/null

   [[ "${rule_text[@]}" =~ (snatpool )"${snatpool_name_list[$i]}"([[:space:]]|\\n) ]] && orphan=false || echo null >/dev/null
   [[ "${rule_text[@]}" =~ (snatpool )"${snatpool_fullPath_list[$i]}"([[:space:]]|\\n) ]] && orphan=false || echo null >/dev/null

   [[ "${datagroup_text[@]}" =~ "\"${snatpool_name_list[$i]}"([[:space:]]|\") ]] && orphan=false || echo null >/dev/null
   [[ "${datagroup_text[@]}" =~ "\"${snatpool_fullPath_list[$i]}"([[:space:]]|\") ]] && orphan=false || echo null >/dev/null

  # If orphan flag is still true, than report status
  if $orphan
  then
     echo "   ${snatpool_fullPath_list[$i]}  --  Orphaned"
  fi
done
