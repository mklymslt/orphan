echo 'Please, inform BIG-IP managemnt IP, username and password to connect to the BIG-IP'
read -p 'BIG-IP mgmt IP: ' host
read -p 'Username: ' user
read -sp 'Password: ' pass
echo ""

# Collect pool member monitor names and put in variable pool_member_monitor_list.
pool_member_monitors=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/pool?expandSubcollections=true | jq .items[].membersReference.items[]?.monitor | awk 1 ORS=' ')
pool_member_monitor_list=($(echo "$pool_member_monitors" | tr ' ' '\n'))
# echo "-Pool Member Monitors------------------------"
# echo "${pool_member_monitor_list[@]}"
# echo "---------------------------------------------"

# Collect pool monitor names and put in variable pool_monitor_list.
pool_monitors=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/pool | jq .items[].monitor? | awk 1 ORS=' ')
pool_monitor_list=($(echo "$pool_monitors" | tr ' ' '\n'))
# echo "-Pool Monitors------------------------"
# echo "${pool_monitor_list[@]}"
# echo "---------------------------------------------"

# Collect node monitor names and put in variable node_monitor_list.
node_monitors=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/node | jq .items[].monitor | awk 1 ORS=' ')
node_monitor_list=($(echo "node_monitors" | tr ' ' '\n'))
# echo "-Node Monitors------------------------"
# echo "${node_monitor_list[@]}"
# echo "---------------------------------------------"

# Collect default-node-monitor names and put in variable default_node_monitor_list.
default_node_monitor=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/default-node-monitor | jq .rule)
#default_node_monitor=($(echo "default_node_monitor" | tr ' ' '\n'))
# echo "-Node Monitors------------------------"
# echo "$default_node_monitor"
# echo "---------------------------------------------"

# The monitor_types was pulled from documentation and the Big-IP config and will be used to iterate through the profile types and collect all profiles on the device.
monitor_types=("diameter" "external" "firepass" "ftp" "gateway-icmp" "http" "https" "icmp" "imap" "inband" "ldap" "module-score" "mssql" "mysql" "nntp" "oracle" "pop3" "postgresql" "radius" "radius-accounting" "real-server" "rpc" "sasp" "scripted" "sip" "smb" "smtp" "snmp-dca" "snmp-dca-base" "soap" "tcp" "tcp-echo" "tcp-half-open" "udp" "dns" "virtual-location" "wap" "wmi" "mqtt" "http2" "http2")

# The system monitors based on the /config/monitors/builtins/base_monitors.conf file and will be used to exclude these monitors from orphan checking. 
system_monitors=("/Common/diameter" "/Common/external" "/Common/firepass" "/Common/ftp" "/Common/gateway_icmp" "/Common/http" "/Common/http_head_f5" "/Common/https" "/Common/https_443" "/Common/https_head_f5" "/Common/icmp" "/Common/imap" "/Common/inband" "/Common/ldap" "/Common/module_score" "/Common/mssql" "/Common/mysql" "/Common/nntp" "/Common/oracle" "/Common/pop3" "/Common/postgresql" "/Common/radius" "/Common/radius_accounting" "/Common/real_server" "/Common/rpc" "/Common/sasp" "/Common/scripted" "/Common/sip" "/Common/smb" "/Common/smtp" "/Common/snmp_dca" "/Common/snmp_dca_base" "/Common/soap" "/Common/tcp" "/Common/tcp_echo" "/Common/tcp_half_open" "/Common/udp" "/Common/dns" "/Common/virtual_location" "/Common/wap" "/Common/wmi" "/Common/mqtt" "/Common/http2" "/Common/http2_head_f5") 

# Collect names from all profiles that are not in the system_monitors list and put in variable monitor_names.
monitor_names=()
for typ in "${monitor_types[@]}"
do
  monitor_fullPaths=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/monitor/$typ | jq -r .items[]?.fullPath? | awk 1 ORS=' ')
  monitor_fullPath_list=($(echo "$monitor_fullPaths" | tr ' ' '\n'))

  # echo "--------------------------"
  # echo "${monitor_fullPath_list[@]}"
  # echo "--------------------------"

  for monitor in "${monitor_fullPath_list[@]}"
  do
    # echo "####  $monitor"
    [[ "${system_monitors[@]}" =~ "$monitor" ]] && echo null >/dev/null || monitor_names+=("$monitor")
  done
done
#echo ""
# echo "Non-System monitors configured on Big-IP -"
# echo "${monitor_names[@]}"
# echo ""

echo ""
echo "Checking for orphan monitors - "
echo ""

# Iterate through entries in monitor_names
for monitor in "${monitor_names[@]}"
do
   # Initialize orphan flag to true
   orphan=true
   # For each entry in the monitor_list, check to see if it is in the any of the lists - pool_member_monitor_list, pool_monitor_list, node_monitor_list or default_node_monitor.  
   # If found set orphan flag to false.

   # The pool_member_list elements include enclosing double-quotes.  For the comparison, encosing double-quotes are added to the node_address_list element.
   [[ "${pool_member_monitor_list[@]}" =~ ([[:space:]]|\")"$monitor"([[:space:]]|\") ]] && orphan=false || echo null >/dev/null

   # The node reference notation for traffic policies allow for the inclusion of a port specification, separated by a colon or simply the IPv4/IPv6 address
   # For the comparison, a leading double-quote is included and either a trailing colon or double-quote is checked for.
   [[ "${pool_monitor_list[@]}" =~ ([[:space:]]|\")"$monitor"([[:space:]]|\") ]] && orphan=false || echo null >/dev/null

   # The node reference notation for rules includes the preceding keyword "node" and allows for the inclusion of a port specification, separated by a colon or a space
   # or simply the IPv4/IPv6 address.  For the comparison, a modified representation is used including the preceding "node" keyword and either a trailing space, colon 
   # or new line character.
   [[ "${node_monitor_list[@]}" =~ ([[:space:]]|\")"$monitor"([[:space:]]|\") ]] && orphan=false || echo null >/dev/null

   # The default_node_monitor is a single string.  
   [[ "default_node_monitor" =~ ([[:space:]]|\")"$monitor"([[:space:]]|\") ]] && orphan=false || echo null >/dev/null
   # If orphan flag is still true, than report status
   if $orphan
   then
      echo "   $monitor  --  Orphaned"
   fi
done
