echo 'Please, inform BIG-IP managemnt IP, username and password to connect to the BIG-IP'
read -p 'BIG-IP mgmt IP: ' host
read -p 'Username: ' user
read -sp 'Password: ' pass
echo ""

# Collect irule names assigned to virtual servers.
vs_rules=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/virtual | jq .items[].rules[]? | awk 1 ORS=' ')
vs_rule_list=($(echo "$vs_rules" | tr ' ' '\n'))

# echo ""
# echo "Rules found in virtuals - ${vs_rule_list[@]}"
# echo ""

# Collect names from all rules and put in variable rule_names.
rule_fullPath_names=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/rule | jq .items[].fullPath | awk 1 ORS=' ')
rule_fullPath_list=($(echo "$rule_fullPath_names" | tr ' ' '\n'))

# echo ""
# echo "Rules configured on Big-IP -"
# echo "${rule_fullPath_list[@]}"
# echo ""

echo "Checking for orphan rules -"
echo ""
# Iterate through entries in rule_names
for rule in "${rule_fullPath_list[@]}"
do
   if [[ "${rule}" != "\"/Common/_sys_"* ]]
   then
     # Initialize orphan flag to true
     orphan=true
     # For each entry in rule_names, check to see if it is in rules_in_virtuals list.
     # Include \" to enclose $rule to perform exact match
     # If found set orphan flag to false.
     [[ "${vs_rule_list[@]}" =~ "${rule}" ]] && orphan=false || echo null >/dev/null
     # If orphan flag is still true, than report status
     if $orphan
     then
	   rule=$(echo "${rule}" | sed 's/\"//g')
       echo "   ${rule}  --  Orphaned"
     fi
   fi
done
