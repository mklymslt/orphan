echo 'Please, inform BIG-IP managemnt IP, username and password to connect to the BIG-IP'
read -p 'BIG-IP mgmt IP: ' host
read -p 'Username: ' user
read -sp 'Password: ' pass
echo ""

# Collect pool details including pool members and put in variable pool_member_list.
pool_members=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/pool?expandSubcollections=true | jq .items[].membersReference.items[]?.address | awk 1 ORS=' ')
pool_member_list=($(echo "$pool_members" | tr ' ' '\n'))
# echo "-Pool Members--------------------------------"
# echo "${pool_member_list[@]}"
# echo "---------------------------------------------"

# Collect text from all rules and put in variable rule_text.
rules=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/rule | jq .items[].apiAnonymous | awk 1 ORS=' ')
rule_text=($(echo "$rules" | tr ' ' '\n'))
# echo "-iRule text----------------------------------"
# echo "${rule_text[@]}"
# echo "---------------------------------------------"
  
# Collect node references, if present from all rules in all traffic policies actions and put in variable traffic_policy_text.
traffic_policy=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/policy | jq -r .items[].fullPath | awk 1 ORS=' ')
traffic_policy_text=()
for policy in $traffic_policy
do
   policy=$(echo "$policy" | awk '{gsub("/", "~", $0); print}')
   traffic_policy_text+=($(curl -sku $user:$pass https://$host/mgmt/tm/ltm/policy/$policy/rules?expandSubcollections=true | jq .items[].actionsReference?.items[].node? | awk 1 ORS=' '))
done
# echo "-Traffic Policy Text------------------------------"
# echo "${traffic_policy_text[@]}"
# echo "---------------------------------------------"
  

# Collect text from all internal datagroup records and put in variable datagroup_text.
datagroup_records=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/data-group/internal | jq .items[].records | awk 1 ORS=' ')
datagroup_text=($(echo "$datagroup_records" | tr ' ' '\n'))
# echo "-Datagroup text------------------------------"
# echo "${datagroup_text[@]}"
# echo "---------------------------------------------"

# Collect node fullPath names and put in variable node_fullPath_list.
node_fullPaths=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/node | jq -r .items[].fullPath | awk 1 ORS=' ')
node_fullPath_list=($(echo "$node_fullPaths" | tr ' ' '\n'))
# echo "-Node Full Paths-----------------------------"
# echo "${node_fullPath_list[@]}"
# echo "---------------------------------------------"

# Collect node addresses and put in variable node_address_list.
node_addresses=$(curl -sku $user:$pass https://$host/mgmt/tm/ltm/node | jq -r .items[].address | awk 1 ORS=' ')
node_address_list=($(echo "$node_addresses" | tr ' ' '\n'))
# echo "-Node Addresses------------------------------"
# echo "${node_address_list[@]}"
# echo "---------------------------------------------"
  
echo ""
echo "Checking for orphan nodes - "
echo ""

# Iterate through entries in node_fullPath_list
len=${#node_fullPath_list[@]}
for (( i=0; i<$len; i++))
do
   # Initialize orphan flag to true
   orphan=true
   # For each entry in the node_list, check to see if it is in the any of the lists - pool_member_list, traffic_policy_text, rule_text or datagroup_text.  
   # If found set orphan flag to false.

   # The pool_member_list elements include enclosing double-quotes.  For the comparison, encosing double-quotes are added to the node_address_list element.
   [[ "${pool_member_list[@]}" =~ "\"${node_address_list[$i]}\"" ]] && orphan=false || echo null >/dev/null

   # The node reference notation for traffic policies allow for the inclusion of a port specification, separated by a colon or simply the IPv4/IPv6 address
   # For the comparison, a leading double-quote is included and either a trailing colon or double-quote is checked for.
   [[ "${traffic_policy_text[@]}" =~ "\"${node_address_list[$i]}"(:|\") ]] && orphan=false || echo null >/dev/null

   # The node reference notation for rules includes the preceding keyword "node" and allows for the inclusion of a port specification, separated by a colon or a space
   # or simply the IPv4/IPv6 address.  For the comparison, a modified representation is used including the preceding "node" keyword and either a trailing space, colon 
   # or new line character.
   checked_node=$(echo "${node_address_list[$i]}" | sed 's/^/node /')
   [[ "${rule_text[@]}" =~ "${checked_node}"([[:space:]]|:|\\n) ]] && orphan=false || echo null >/dev/null

   # The node reference notation for datagroups is based on the utilization in an iRule, so the format is similar, without the "node" keyword.  For the comparison,
   # a leading double-quote is used and a trailing space, colon or double-quote is allowed.
   [[ "${datagroup_text[@]}" =~ "\"${node_address_list[$i]}"([[:space:]]|:|\") ]] && orphan=false || echo null >/dev/null
   # If orphan flag is still true, than report status
   if $orphan
   then
      echo "   ${node_fullPath_list[$i]}  --  Orphaned"
   fi
done
